
public class Utils {

//	M�todo que lanza una excepci�n
	public static double squareRoot(double d) throws NegativeException {
		if(d < 0) throw new NegativeException(d);
		return Math.sqrt(d);
	}
	
//	M�todo que propaga una excepci�n recibida (no la maneja)
	public static double chicharronero(double a, double b, double c) 
	                                        throws NegativeException {
		return (-b + squareRoot(b * b - 4 * a * c)) / (2 * a);
	}
	
	public static void main(String[] args) throws NegativeException {
		double sr = squareRoot(4.5);
		System.out.println(sr);
		double x  = chicharronero(1, 4, 2);
		System.out.println(x);
		
//		try {
//			double sr = squareRoot(-4.5);
//			System.out.println(sr);
//		} catch (NegativeException e) {
//			e.printStackTrace();
//		}
		
		System.out.println("Seguimos en el m�todo main");		
		
	}

}

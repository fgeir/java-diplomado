
public enum Idioma {

	ESPA�OL, FRANCES, INGLES;
	
}

package shapes2d;

public class Vec2 {

	private double x, y;

	public Vec2() {
		this.x = 0;
		this.y = 0;
	}
	
	public Vec2(double x, double y) {
		setX(x);
		setY(y);
	}
	
	public double getX() {
		return x;
	}

	public void setX(double x) {
		this.x = x;
	}

	public double getY() {
		return y;
	}

	public void setY(double y) {
		this.y = y;
	}
	
	
}

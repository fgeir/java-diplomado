package com.iteso.model;

public class Date {

	private int    day = 1, month = 1, year = 2017;
	private String monthName = "Enero";
	private int    format = 0;
	
	public Date() {
//		Keeps default values: 1-ene-2017
	}

	public Date(int day, int month, int year) {
		setYear(year);
		setMonth(month);
		setDay(day);
	}

	public Date(int day, int month, int year, int format) {
		this(day, month, year);  // invoca al constructor anterior
		setFormat(format);
	}

	public int getDay() {
		return day;
	}

	public void setDay(int day) {
//		Si el día está fuera de rango [1..31], cancelar
//		Si es febrero y day > 28, cancelar
//		Si es un mes de 30 días y day > 30, cancelar
//		Cualquier otro caso es correcto
		if(day < 1                 || 
		   day > 31                ||
		   day > 28 &&  month == 2 ||
		   day > 30 && (month == 4 || month == 6 || month == 9 || month == 11) 
		) return;
		this.day = day;
	}

	public int getMonth() {
		return month;
	}

	public void setMonth(int month) {
		if(month >= 1 && month <= 12) {
			this.month = month;
			switch(this.month) {
				case  1: this.monthName = "Enero"; 		break; 
				case  2: this.monthName = "Febrero"; 	break;
				case  3: this.monthName = "Marzo"; 		break;
				case  4: this.monthName = "Abril"; 		break;
				case  5: this.monthName = "Mayo"; 		break;
				case  6: this.monthName = "Junio";      break;
				case  7: this.monthName = "Julio";      break;
				case  8: this.monthName = "Agosto";     break;
				case  9: this.monthName = "Septiembre"; break;
				case 10: this.monthName = "Octubre";    break;
				case 11: this.monthName = "Noviembre";  break;
				default: this.monthName = "Diciembre";
			}
		}
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		if(year >= 1900 && year <= 3000) this.year = year;
	}

	public int getFormat() {
		return format;
	}

	public void setFormat(int format) {
		if(format >= 0 && format <= 2) this.format = format;
	}

	public String getMonthName() {
		return monthName;
	}
	
	@Override
	public String toString() {
//		"05/09/06", si format = 0
//		"5-Sep-2006", si format = 1
//		"5 de septiembre de 2006", si format = 2
		switch(this.format) {
			case 0  : return String.format("%02d/%02d/%02d", this.day, this.month, this.year % 100);
			case 1  : return String.format("%d-%s-%d", this.day, this.monthName.substring(0, 3), this.year);
			default : return String.format("%d de %s de %d", this.day, this.monthName.toLowerCase(), this.year);
		}
	}
	
	@Override
	public boolean equals(Object o) {
		return false;
	}

	@Override
	public Date clone() {
		return null;
	}
	
	public void next() {
		
	}

}

package tests;

import com.iteso.model.Date;

public class TestDate {

	public static void main(String[] args) {
		Date d1 = new Date();
		Date d2 = new Date(31, 12, 2016);
		d1.setFormat(2);
		d2.setFormat(2);
		System.out.println(d1);
		System.out.println(d2);
	}

}
